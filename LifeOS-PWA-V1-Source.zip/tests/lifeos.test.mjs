import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("ships the complete LifeOS product shell", async () => {
  const [page, curriculum, manifest, serviceWorker] = await Promise.all([
    readFile(new URL("app/page.tsx", root), "utf8"),
    readFile(new URL("app/curricula.ts", root), "utf8"),
    readFile(new URL("public/manifest.webmanifest", root), "utf8"),
    readFile(new URL("public/sw.js", root), "utf8"),
  ]);

  assert.match(page, /英语训练/);
  assert.match(page, /投资学习/);
  assert.match(page, /阅读输入/);
  assert.match(page, /localStorage/);
  assert.match(page, /chatgpt\.com/);
  assert.match(page, /每日课程/);
  assert.match(page, /即时记忆卡/);
  assert.match(page, /真实对话/);
  assert.match(page, /语法解码/);
  assert.match(page, /进度评估/);
  assert.match(page, /沉浸理解/);
  assert.match(page, /TargetLanguage/);
  assert.match(curriculum, /englishCurriculum/);
  assert.match(curriculum, /investingCurriculum/);
  assert.equal(JSON.parse(manifest).display, "standalone");
  assert.match(serviceWorker, /CACHE_NAME/);
});
