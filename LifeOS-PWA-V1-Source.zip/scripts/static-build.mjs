import { spawnSync } from "node:child_process";
import process from "node:process";

const executable = process.platform === "win32"
  ? "node_modules\\.bin\\next.CMD"
  : "node_modules/.bin/next";

const result = spawnSync(executable, ["build"], {
  stdio: "inherit",
  shell: process.platform === "win32",
  env: {
    ...process.env,
    LIFEOS_STATIC_EXPORT: "true",
  },
});

process.exit(result.status ?? 1);
