# LifeOS 学习成长工作台

一款手机优先、可安装到主屏幕的 PWA 学习工具。第一版包含：

- 今日仪表盘：英语 60 分钟、投资 120 分钟、阅读 120 分钟
- 英语 33 天课程：每天一个真实情景、核心表达、对话起点和输出任务
- 语言训练工具箱：英语 / 法语切换，包含 30 分钟课程、20 词记忆卡、真实对话、语法解码、10 题周测和沉浸理解
- 投资 90 天课程：从财务语言到完整企业研究
- 阅读知识库：摘录、理解、现实应用、搜索和 JSON 备份
- AI 导师：英语、企业分析和阅读三个 ChatGPT 快捷入口
- 当前设备本地保存、每日自动切换、连续学习天数、离线访问

## 在电脑上运行

需要 Node.js 22 或更新版本。

```bash
pnpm install
pnpm dev
```

打开终端显示的网址即可。也可以使用 npm：

```bash
npm install
npm run dev
```

## 免费部署到 Vercel

1. 在 GitHub 新建一个仓库并上传本项目全部文件。
2. 登录 Vercel，选择 **Add New → Project**。
3. 导入刚才的 GitHub 仓库，保持默认设置，点击 **Deploy**。
4. 部署完成后，用手机打开 Vercel 提供的 HTTPS 地址。

Vercel 会自动识别 Next.js，无需服务器或数据库。

## 免费部署到 GitHub Pages

项目已经包含自动部署文件：`.github/workflows/deploy-pages.yml`。

1. 把项目上传到 GitHub 仓库。
2. 打开仓库 **Settings → Pages**。
3. 在 **Build and deployment** 中选择 **GitHub Actions**。
4. 推送到 `main` 分支后，等待 Actions 完成。
5. Pages 页面会显示公开网址。

## 安装到手机桌面

### iPhone / iPad

1. 必须使用 Safari 打开已部署的 HTTPS 地址。
2. 点击底部“分享”。
3. 选择“添加到主屏幕”。

### Android

1. 使用 Chrome 打开已部署的 HTTPS 地址。
2. 点击浏览器菜单中的“安装应用”或“添加到主屏幕”。

## 数据说明

学习进度和阅读笔记使用浏览器本地存储：不需要注册，不会上传到服务器。更换浏览器、清除网站数据或更换手机后，原数据不会自动同步。阅读知识库中的“导出备份”可下载 JSON 备份文件。

## 项目结构

- `app/page.tsx`：全部页面与交互
- `app/curricula.ts`：英语和投资课程内容
- `app/globals.css`：移动端与桌面端样式
- `public/manifest.webmanifest`：PWA 安装信息
- `public/sw.js`：离线缓存
- `.github/workflows/deploy-pages.yml`：GitHub Pages 自动部署

## 修改内容

课程文本集中在 `app/curricula.ts`。每日目标时长位于 `app/page.tsx` 顶部的 `GOALS`。修改后重新部署即可。
