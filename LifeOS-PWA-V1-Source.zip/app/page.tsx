"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { englishCurriculum, investingCurriculum } from "./curricula";

type Tab = "home" | "learn" | "notes" | "mentor";
type Track = "english" | "stocks";
type ProgressKey = "english" | "stocks" | "reading";
type DailyProgress = Record<ProgressKey, number>;
type ProgressHistory = Record<string, DailyProgress>;

type ReadingNote = {
  id: string;
  title: string;
  quote: string;
  understanding: string;
  application: string;
  tags: string[];
  createdAt: string;
};

type CourseState = {
  english: number[];
  stocks: number[];
};

type LanguageTool = "course" | "cards" | "conversation" | "grammar" | "quiz" | "immersion";
type TargetLanguage = "英语" | "法语";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const GOALS: Record<ProgressKey, number> = {
  english: 60,
  stocks: 120,
  reading: 120,
};

const EMPTY_PROGRESS: DailyProgress = { english: 0, stocks: 0, reading: 0 };
const STORAGE = {
  progress: "lifeos-progress-v1",
  courses: "lifeos-courses-v1",
  notes: "lifeos-notes-v1",
};

const progressCards: Array<{
  key: ProgressKey;
  kicker: string;
  title: string;
  subtitle: string;
  color: string;
}> = [
  { key: "english", kicker: "EN", title: "英语训练", subtitle: "情景对话 · 开口表达", color: "mint" },
  { key: "stocks", kicker: "ROI", title: "投资学习", subtitle: "企业分析 · 长期思维", color: "amber" },
  { key: "reading", kicker: "READ", title: "阅读输入", subtitle: "摘录 · 思考 · 应用", color: "blue" },
];

const mentorCards = [
  {
    id: "english",
    label: "English tutor",
    title: "英语口语老师",
    description: "围绕今日主题展开真实对话，逐句纠正但不中断表达。",
    accent: "mint",
    action: "开始今日口语练习",
  },
  {
    id: "stocks",
    label: "Business analyst",
    title: "企业分析导师",
    description: "按巴菲特式框架拆解商业模式、护城河、财务质量与估值。",
    accent: "amber",
    action: "分析一家企业",
  },
  {
    id: "reading",
    label: "Reading guide",
    title: "阅读思考导师",
    description: "把难概念讲简单，并连接真实商业场景与个人行动。",
    accent: "blue",
    action: "解释一个概念",
  },
] as const;

const mentorPrompts = {
  english:
    "你现在是我的英语口语老师。我的目标是通过每天 1 小时练习提升真实交流能力。请围绕一个生活或商务情景和我进行英文对话：一次只问一个问题；先让我完整回答；再用简短中文指出最重要的语法或表达问题；给出更自然的英文版本；然后继续追问。请控制难度在我能理解但略有挑战的水平。现在直接用英文开始今天的对话。",
  stocks:
    "你现在是我的长期投资导师，请采用巴菲特式企业分析框架帮助我研究一家公司。请依次分析：1. 公司怎样赚钱；2. 客户为什么选择它；3. 护城河及其证据；4. 收入、利润、ROE、自由现金流和负债质量；5. 行业与管理层风险；6. 合理估值区间和安全边际。不要直接给买卖建议，先问我想分析哪家公司，以及我已经掌握哪些资料。",
  reading:
    "你现在是我的阅读导师。请把我提供的书中概念用简单语言解释，先给一句话结论，再用一个生活类比和一个真实商业案例说明，然后指出这个观点的适用边界，最后问我一个能促进思考的问题，并帮助我形成可执行的现实应用。现在请先问我正在读哪本书、哪段内容不理解。",
};

const languageTools: Array<{ id: LanguageTool; number: string; title: string; hint: string }> = [
  { id: "course", number: "01", title: "每日课程", hint: "30 分钟定制课" },
  { id: "cards", number: "02", title: "即时记忆卡", hint: "20 个词深度记忆" },
  { id: "conversation", number: "03", title: "真实对话", hint: "边聊边纠错" },
  { id: "grammar", number: "04", title: "语法解码", hint: "规则与常见错误" },
  { id: "quiz", number: "05", title: "进度评估", hint: "10 题周测" },
  { id: "immersion", number: "06", title: "沉浸理解", hint: "翻译与追问" },
];

function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function safeParse<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function chatGPTUrl(prompt: string) {
  return `https://chatgpt.com/?q=${encodeURIComponent(prompt)}`;
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [track, setTrack] = useState<Track>("english");
  const [todayKey, setTodayKey] = useState("");
  const [history, setHistory] = useState<ProgressHistory>({});
  const [courseState, setCourseState] = useState<CourseState>({ english: [], stocks: [] });
  const [notes, setNotes] = useState<ReadingNote[]>([]);
  const [englishDay, setEnglishDay] = useState(1);
  const [stockDay, setStockDay] = useState(1);
  const [targetLanguage, setTargetLanguage] = useState<TargetLanguage>("英语");
  const [languageTool, setLanguageTool] = useState<LanguageTool>("course");
  const [courseSkill, setCourseSkill] = useState("会话");
  const [languageToolInputs, setLanguageToolInputs] = useState<Record<LanguageTool, string>>({
    course: "日常自我介绍",
    cards: "",
    conversation: "旅行计划",
    grammar: "",
    quiz: "",
    immersion: "",
  });
  const [query, setQuery] = useState("");
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installHelpOpen, setInstallHelpOpen] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const [toast, setToast] = useState("");
  const [noteForm, setNoteForm] = useState({
    title: "",
    quote: "",
    understanding: "",
    application: "",
    tags: "",
  });

  useEffect(() => {
    const key = localDateKey();
    setTodayKey(key);
    setHistory(safeParse(localStorage.getItem(STORAGE.progress), {}));
    setCourseState(
      safeParse(localStorage.getItem(STORAGE.courses), { english: [], stocks: [] }),
    );
    setNotes(safeParse(localStorage.getItem(STORAGE.notes), []));
    setIsStandalone(
      window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as Navigator & { standalone?: boolean }).standalone === true,
    );
    setIsIos(/iphone|ipad|ipod/i.test(window.navigator.userAgent));

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("./sw.js").catch(() => undefined);
    }

    const capturePrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", capturePrompt);
    return () => window.removeEventListener("beforeinstallprompt", capturePrompt);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const todayProgress = history[todayKey] ?? EMPTY_PROGRESS;
  const totalMinutes = Object.values(todayProgress).reduce((sum, value) => sum + value, 0);
  const totalGoal = Object.values(GOALS).reduce((sum, value) => sum + value, 0);
  const overallPercent = Math.round((totalMinutes / totalGoal) * 100);

  const streak = useMemo(() => {
    if (!todayKey) return 0;
    let count = 0;
    const cursor = new Date();
    const todayHasLearning = Object.values(history[todayKey] ?? EMPTY_PROGRESS).some((value) => value > 0);
    if (!todayHasLearning) cursor.setDate(cursor.getDate() - 1);
    while (true) {
      const key = localDateKey(cursor);
      const hasLearning = Object.values(history[key] ?? EMPTY_PROGRESS).some((value) => value > 0);
      if (!hasLearning) break;
      count += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
    return count;
  }, [history, todayKey]);

  const dateLabel = useMemo(
    () =>
      new Intl.DateTimeFormat("zh-CN", {
        month: "long",
        day: "numeric",
        weekday: "long",
      }).format(new Date()),
    [],
  );

  const filteredNotes = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return notes;
    return notes.filter((note) =>
      [note.title, note.quote, note.understanding, note.application, ...note.tags]
        .join(" ")
        .toLowerCase()
        .includes(normalized),
    );
  }, [notes, query]);

  function updateProgress(key: ProgressKey, delta: number) {
    const date = todayKey || localDateKey();
    const current = history[date] ?? EMPTY_PROGRESS;
    const next: ProgressHistory = {
      ...history,
      [date]: {
        ...current,
        [key]: clamp(current[key] + delta, 0, GOALS[key]),
      },
    };
    setHistory(next);
    localStorage.setItem(STORAGE.progress, JSON.stringify(next));
  }

  function openLearning(nextTrack: Track) {
    setTrack(nextTrack);
    setActiveTab("learn");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function toggleCourseDay(course: Track, day: number) {
    const completed = courseState[course];
    const nextDays = completed.includes(day)
      ? completed.filter((item) => item !== day)
      : [...completed, day].sort((a, b) => a - b);
    const next = { ...courseState, [course]: nextDays };
    setCourseState(next);
    localStorage.setItem(STORAGE.courses, JSON.stringify(next));
    setToast(completed.includes(day) ? "已取消课程完成状态" : "课程已完成，继续保持");
  }

  function saveNote(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!noteForm.title.trim() || !noteForm.understanding.trim()) {
      setToast("请填写书名和我的理解");
      return;
    }
    const nextNote: ReadingNote = {
      id: `${Date.now()}`,
      title: noteForm.title.trim(),
      quote: noteForm.quote.trim(),
      understanding: noteForm.understanding.trim(),
      application: noteForm.application.trim(),
      tags: noteForm.tags
        .split(/[，,]/)
        .map((tag) => tag.trim())
        .filter(Boolean),
      createdAt: new Date().toISOString(),
    };
    const next = [nextNote, ...notes];
    setNotes(next);
    localStorage.setItem(STORAGE.notes, JSON.stringify(next));
    setNoteForm({ title: "", quote: "", understanding: "", application: "", tags: "" });
    updateProgress("reading", 15);
    setToast("笔记已保存，阅读进度 +15 分钟");
  }

  function deleteNote(id: string) {
    if (!window.confirm("确定删除这条笔记吗？此操作只影响当前设备。")) return;
    const next = notes.filter((note) => note.id !== id);
    setNotes(next);
    localStorage.setItem(STORAGE.notes, JSON.stringify(next));
    setToast("笔记已删除");
  }

  function exportNotes() {
    const payload = JSON.stringify({ exportedAt: new Date().toISOString(), notes }, null, 2);
    const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `lifeos-reading-notes-${localDateKey()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    setToast("阅读笔记备份已下载");
  }

  async function installApp() {
    if (installPrompt) {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === "accepted") setIsStandalone(true);
      setInstallPrompt(null);
      return;
    }
    setInstallHelpOpen(true);
  }

  async function copyPrompt(prompt: string) {
    try {
      await navigator.clipboard.writeText(prompt);
      setToast("导师提示词已复制");
    } catch {
      setToast("复制失败，请长按文字复制");
    }
  }

  const currentEnglish = englishCurriculum[englishDay - 1];
  const currentStock = investingCurriculum[stockDay - 1];
  const englishPrompt = `${mentorPrompts.english}\n\n今天是 Day ${currentEnglish.day}，主题是“${currentEnglish.theme}”，情景是“${currentEnglish.scene}”。请直接从这个情景开始。`;
  const activeLanguageInput = languageToolInputs[languageTool].trim();
  const activeLanguageToolInfo = languageTools.find((item) => item.id === languageTool) ?? languageTools[0];
  const languageToolPlaceholder: Record<LanguageTool, string> = {
    course: "输入课程主题，例如：在餐厅点餐",
    cards: "粘贴最多 20 个词，可用逗号或换行分隔",
    conversation: "输入你想聊的话题，例如：旅行计划",
    grammar: "输入要解释的语法规则，例如：现在完成时",
    quiz: "概括本周学过的词汇、语法或课程序号",
    immersion: "粘贴一段希望翻译并练习理解的文本",
  };
  const toolPrompt = (() => {
    const language = targetLanguage;
    if (languageTool === "course") {
      return `你是专业的${language}教师。请为我创建一堂完整的 30 分钟${language}课程，重点训练“${courseSkill}”，主题是“${activeLanguageInput || currentEnglish.theme}”。请按时间分配：5 分钟热身、10 分钟讲解、10 分钟练习、5 分钟小测验。必须包含清晰例子、由易到难的练习，以及最后的小测验。用中文解释关键点，主要练习使用${language}。一次只推进一个环节，等待我完成后再继续；小测验答案必须等我全部作答后才显示。`;
    }
    if (languageTool === "cards") {
      const words = activeLanguageInput || currentEnglish.vocabulary.join("、");
      return `你是我的${language}词汇教练。请把以下词汇制作成记忆卡：${words}。如果不足 20 个，请补充与这些词同主题、适合初学者的词，凑满 20 个。每张卡必须包括：1. ${language}单词；2. 中文含义；3. 一个自然、简短的${language}用法例句及中文翻译；4. 一个简单记忆建议（联想、词根或场景）。最后用其中 5 个词给我出填空题，等我回答后再公布答案。`;
    }
    if (languageTool === "conversation") {
      return `请扮演一位友好、自然的${language}母语者，和我围绕“${activeLanguageInput || currentEnglish.scene}”进行真实对话。一次只说一到三句话并问一个问题，等待我回答。对话进行时纠正我的错误：先回应内容，再简短指出最重要的语法或用词错误，给出更自然的说法，然后继续聊天。不要一次纠正太多，也不要提前写完整对话脚本。现在直接用${language}开始。`;
    }
    if (languageTool === "grammar") {
      return `你是善于把复杂规则讲简单的${language}语法老师。请解释这条规则：“${activeLanguageInput || "请先问我想学习哪条语法规则"}”。先用一句中文给出核心结论，再用 5 个由易到难的${language}例子说明，并逐句翻译。然后明确指出学生最常犯的 3 个错误，展示“错误句 → 正确句 → 原因”。最后给我 5 道练习题，等我全部完成后再显示答案和解析。`;
    }
    if (languageTool === "quiz") {
      return `你是我的${language}进度评估老师。请根据我本周学习的内容出 10 道题的小测验。本周内容是：“${activeLanguageInput || `Day ${Math.max(1, englishDay - 6)} 至 Day ${englishDay} 的情景会话与核心表达`}”。题目需覆盖词汇、语法、情景表达和短文理解，包含选择、填空、改错和简答。先一次性只给出 10 道题，不提供答案、提示或解析。必须等我提交全部答案后，再逐题评分、解释错误并给出下周建议。`;
    }
    return `你是我的${language}沉浸式学习教练。请把下面文本自然、准确地翻译成${language}：“${activeLanguageInput || "请先让我粘贴一段文本"}”。翻译后不要直接讲解全部内容。请依次向我提问：5 个重点词汇问题、3 个实用短语问题、3 个内容理解问题。一次只问一个问题并等待我回答；我答完后再纠正、解释并进入下一题。最后用${language}让我做一个 3 句话的内容总结。`;
  })();

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setActiveTab("home")} aria-label="返回首页">
          <span className="brand-mark">L</span>
          <span>LifeOS</span>
        </button>
        <div className="topbar-actions">
          <span className="streak-pill"><span className="streak-dot" /> 连续 {streak} 天</span>
          {!isStandalone && (
            <button className="install-button" onClick={installApp}>安装 App</button>
          )}
        </div>
      </header>

      <main className="main-content">
        {activeTab === "home" && (
          <section className="page home-page" aria-labelledby="home-title">
            <div className="hero-grid">
              <div className="hero-copy">
                <p className="eyebrow">{dateLabel}</p>
                <h1 id="home-title">今天，也向前一点。</h1>
                <p className="hero-subtitle">把长期目标拆成今天能完成的一小步。</p>
              </div>
              <div className="daily-score" aria-label={`今日总进度 ${overallPercent}%`}>
                <div
                  className="score-ring"
                  style={{ "--progress": `${Math.min(overallPercent, 100) * 3.6}deg` } as React.CSSProperties}
                >
                  <div><strong>{Math.min(overallPercent, 100)}%</strong><span>今日进度</span></div>
                </div>
                <p><strong>{totalMinutes}</strong> / {totalGoal} 分钟</p>
              </div>
            </div>

            <div className="section-heading">
              <div>
                <p className="eyebrow">Daily focus</p>
                <h2>今日三件事</h2>
              </div>
              <span>{progressCards.filter((card) => todayProgress[card.key] >= GOALS[card.key]).length} / 3 完成</span>
            </div>

            <div className="progress-grid">
              {progressCards.map((card) => {
                const value = todayProgress[card.key];
                const percent = Math.round((value / GOALS[card.key]) * 100);
                return (
                  <article className={`progress-card ${card.color}`} key={card.key}>
                    <div className="card-topline">
                      <span className="subject-mark">{card.kicker}</span>
                      <span className={percent >= 100 ? "done-badge complete" : "done-badge"}>
                        {percent >= 100 ? "今日完成" : `${percent}%`}
                      </span>
                    </div>
                    <h3>{card.title}</h3>
                    <p>{card.subtitle}</p>
                    <div className="progress-track"><span style={{ width: `${percent}%` }} /></div>
                    <div className="minute-row">
                      <div><strong>{value}</strong><span> / {GOALS[card.key]} 分钟</span></div>
                      <div className="stepper" aria-label={`${card.title}时长调整`}>
                        <button onClick={() => updateProgress(card.key, -15)} aria-label={`减少 ${card.title} 15分钟`}>−</button>
                        <button onClick={() => updateProgress(card.key, 15)} aria-label={`增加 ${card.title} 15分钟`}>+15</button>
                      </div>
                    </div>
                    {card.key === "reading" ? (
                      <button className="card-link" onClick={() => setActiveTab("notes")}>记录阅读笔记 <span>→</span></button>
                    ) : (
                      <button className="card-link" onClick={() => openLearning(card.key === "english" ? "english" : "stocks")}>继续今日课程 <span>→</span></button>
                    )}
                  </article>
                );
              })}
            </div>

            <div className="insight-strip">
              <span className="quote-mark">“</span>
              <div>
                <p>真正的复利，来自每天都没有中断。</p>
                <span>今天累计专注 {totalMinutes} 分钟 · 已完成 {courseState.english.length + courseState.stocks.length} 节课程</span>
              </div>
              <button onClick={() => setActiveTab("learn")}>查看计划</button>
            </div>
          </section>
        )}

        {activeTab === "learn" && (
          <section className="page learning-page" aria-labelledby="learn-title">
            <div className="page-intro">
              <p className="eyebrow">Learning path</p>
              <h1 id="learn-title">把知识，练成能力。</h1>
              <p>英语重在开口，投资重在证据。每天完成一课即可。</p>
            </div>

            <div className="segmented-control" aria-label="选择学习计划">
              <button className={track === "english" ? "active" : ""} onClick={() => setTrack("english")}>英语 · 33 天</button>
              <button className={track === "stocks" ? "active" : ""} onClick={() => setTrack("stocks")}>投资 · 90 天</button>
            </div>

            {track === "english" ? (
              <div className="course-layout">
                <aside className="course-sidebar">
                  <div className="course-progress-card mint">
                    <span>English speaking</span>
                    <strong>{courseState.english.length}<small> / 33 天</small></strong>
                    <div className="progress-track"><span style={{ width: `${(courseState.english.length / 33) * 100}%` }} /></div>
                    <p>情景输入 → 开口对话 → 即时纠正</p>
                  </div>
                  <div className="day-list" aria-label="英语课程天数">
                    {englishCurriculum.map((item) => (
                      <button
                        key={item.day}
                        className={`${englishDay === item.day ? "active" : ""} ${courseState.english.includes(item.day) ? "completed" : ""}`}
                        onClick={() => setEnglishDay(item.day)}
                      >
                        <span>Day {item.day}</span>
                        <small>{item.theme}</small>
                      </button>
                    ))}
                  </div>
                </aside>

                <article className="lesson-card">
                  <div className="lesson-meta"><span>Day {currentEnglish.day}</span><span>约 60 分钟</span></div>
                  <h2>{currentEnglish.theme}</h2>
                  <p className="lesson-scene">今日情景：{currentEnglish.scene}</p>

                  <div className="lesson-block">
                    <h3><span>01</span>核心词汇</h3>
                    <div className="word-chips">
                      {currentEnglish.vocabulary.map((word) => <span key={word}>{word}</span>)}
                    </div>
                  </div>

                  <div className="lesson-block">
                    <h3><span>02</span>自然表达</h3>
                    <ul className="phrase-list">
                      {currentEnglish.phrases.map((phrase) => <li key={phrase}>{phrase}</li>)}
                    </ul>
                  </div>

                  <div className="lesson-block">
                    <h3><span>03</span>对话起点</h3>
                    <div className="dialogue-box">
                      {currentEnglish.dialogue.map(([speaker, line], index) => (
                        <div className={speaker === "AI" ? "ai-line" : "user-line"} key={`${speaker}-${index}`}>
                          <span>{speaker}</span><p>{line}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mission-box">
                    <span>今日输出任务</span>
                    <p>{currentEnglish.mission}</p>
                  </div>

                  <div className="lesson-actions">
                    <a className="primary-action" href={chatGPTUrl(englishPrompt)} target="_blank" rel="noreferrer">与 AI 开始对话</a>
                    <button
                      className={courseState.english.includes(currentEnglish.day) ? "secondary-action completed" : "secondary-action"}
                      onClick={() => toggleCourseDay("english", currentEnglish.day)}
                    >
                      {courseState.english.includes(currentEnglish.day) ? "已完成本课" : "标记为已完成"}
                    </button>
                  </div>

                  <section className="language-lab" aria-labelledby="language-lab-title">
                    <div className="language-lab-head">
                      <div>
                        <span>AI language lab</span>
                        <h3 id="language-lab-title">语言训练工具箱</h3>
                        <p>选择一种训练方式，带着你的内容直接进入 ChatGPT。</p>
                      </div>
                      <div className="language-switch" aria-label="目标语言">
                        {(["英语", "法语"] as TargetLanguage[]).map((language) => (
                          <button
                            key={language}
                            className={targetLanguage === language ? "active" : ""}
                            onClick={() => setTargetLanguage(language)}
                          >
                            {language}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="language-tool-tabs" aria-label="语言训练模式">
                      {languageTools.map((tool) => (
                        <button
                          key={tool.id}
                          className={languageTool === tool.id ? "active" : ""}
                          onClick={() => setLanguageTool(tool.id)}
                        >
                          <span>{tool.number}</span>
                          <strong>{tool.title}</strong>
                          <small>{tool.hint}</small>
                        </button>
                      ))}
                    </div>

                    <div className="language-tool-panel">
                      <div className="tool-panel-heading">
                        <span>{activeLanguageToolInfo.number}</span>
                        <div><h4>{activeLanguageToolInfo.title}</h4><p>当前目标语言：{targetLanguage}</p></div>
                      </div>

                      {languageTool === "course" && (
                        <label className="tool-field compact">
                          训练重点
                          <select value={courseSkill} onChange={(event) => setCourseSkill(event.target.value)}>
                            <option>语法</option>
                            <option>会话</option>
                            <option>听力理解</option>
                          </select>
                        </label>
                      )}

                      <label className="tool-field">
                        {languageTool === "cards" ? "词汇列表" : languageTool === "immersion" ? "原始文本" : languageTool === "quiz" ? "本周所学" : "训练内容"}
                        {languageTool === "cards" || languageTool === "quiz" || languageTool === "immersion" ? (
                          <textarea
                            rows={languageTool === "immersion" ? 5 : 3}
                            value={languageToolInputs[languageTool]}
                            onChange={(event) => setLanguageToolInputs({ ...languageToolInputs, [languageTool]: event.target.value })}
                            placeholder={languageToolPlaceholder[languageTool]}
                          />
                        ) : (
                          <input
                            value={languageToolInputs[languageTool]}
                            onChange={(event) => setLanguageToolInputs({ ...languageToolInputs, [languageTool]: event.target.value })}
                            placeholder={languageToolPlaceholder[languageTool]}
                          />
                        )}
                      </label>

                      {languageTool === "cards" && (
                        <button
                          className="use-today-words"
                          onClick={() => setLanguageToolInputs({ ...languageToolInputs, cards: currentEnglish.vocabulary.join("、") })}
                        >
                          使用 Day {currentEnglish.day} 今日词汇
                        </button>
                      )}

                      <div className="tool-prompt-preview">
                        <span>导师会这样工作</span>
                        <p>
                          {languageTool === "course" && "按 5+10+10+5 分钟结构推进，包含例子、练习和最后小测。"}
                          {languageTool === "cards" && "生成 20 张记忆卡，每张都有用法例句和初学者记忆建议。"}
                          {languageTool === "conversation" && "扮演母语者自然交流，回应内容后再简短纠错。"}
                          {languageTool === "grammar" && "简单解释规则，并指出最常见的三个错误。"}
                          {languageTool === "quiz" && "只先显示 10 道题，等你全部作答后再公布答案。"}
                          {languageTool === "immersion" && "先翻译，再逐个追问词汇、短语和内容理解。"}
                        </p>
                      </div>

                      <div className="tool-panel-actions">
                        <a href={chatGPTUrl(toolPrompt)} target="_blank" rel="noreferrer">开始这项训练 <span>↗</span></a>
                        <button onClick={() => copyPrompt(toolPrompt)}>复制完整提示词</button>
                      </div>
                    </div>
                  </section>
                </article>
              </div>
            ) : (
              <div className="course-layout">
                <aside className="course-sidebar">
                  <div className="course-progress-card amber">
                    <span>Long-term investing</span>
                    <strong>{courseState.stocks.length}<small> / 90 天</small></strong>
                    <div className="progress-track"><span style={{ width: `${(courseState.stocks.length / 90) * 100}%` }} /></div>
                    <p>概念理解 → 真实证据 → 独立判断</p>
                  </div>
                  <div className="day-list" aria-label="投资课程天数">
                    {investingCurriculum.map((item) => (
                      <button
                        key={item.day}
                        className={`${stockDay === item.day ? "active" : ""} ${courseState.stocks.includes(item.day) ? "completed" : ""}`}
                        onClick={() => setStockDay(item.day)}
                      >
                        <span>Day {item.day}</span>
                        <small>{item.concept}</small>
                      </button>
                    ))}
                  </div>
                </aside>

                <article className="lesson-card investing-lesson">
                  <div className="lesson-meta"><span>Day {currentStock.day} · {currentStock.phase}</span><span>约 120 分钟</span></div>
                  <h2>{currentStock.concept}</h2>
                  <p className="lesson-scene">{currentStock.phaseDescription}</p>

                  <div className="analysis-flow">
                    <div><span>理解</span><strong>先用自己的话讲清概念</strong><p>不背公式，先理解它在企业经营中回答什么问题。</p></div>
                    <div><span>验证</span><strong>再到真实公司里找证据</strong><p>至少同时寻找支持和反对结论的数据。</p></div>
                    <div><span>输出</span><strong>最后形成可复用判断</strong><p>把结果沉淀为自己的分析卡片与检查清单。</p></div>
                  </div>

                  <div className="lesson-block task-panel">
                    <h3><span>01</span>今日任务</h3>
                    <p>{currentStock.task}</p>
                  </div>
                  <div className="lesson-block task-panel">
                    <h3><span>02</span>今日产出</h3>
                    <p>{currentStock.output}</p>
                  </div>
                  <div className="mission-box amber">
                    <span>研究原则</span>
                    <p>先寻找事实，再形成观点；先理解生意，再讨论价格。</p>
                  </div>

                  <div className="lesson-actions">
                    <a className="primary-action amber" href={chatGPTUrl(`${mentorPrompts.stocks}\n\n我今天正在学习 Day ${currentStock.day}：“${currentStock.concept}”。请先用一个简单商业案例帮助我理解，再带我完成今日任务。`)} target="_blank" rel="noreferrer">请 AI 带我学习</a>
                    <button
                      className={courseState.stocks.includes(currentStock.day) ? "secondary-action completed" : "secondary-action"}
                      onClick={() => toggleCourseDay("stocks", currentStock.day)}
                    >
                      {courseState.stocks.includes(currentStock.day) ? "已完成本课" : "标记为已完成"}
                    </button>
                  </div>
                </article>
              </div>
            )}
          </section>
        )}

        {activeTab === "notes" && (
          <section className="page notes-page" aria-labelledby="notes-title">
            <div className="page-intro notes-intro">
              <div>
                <p className="eyebrow">Reading library</p>
                <h1 id="notes-title">读过，更要留下来。</h1>
                <p>摘录只是开始，把它变成自己的理解和行动。</p>
              </div>
              <div className="notes-stat"><strong>{notes.length}</strong><span>条思考</span></div>
            </div>

            <div className="notes-layout">
              <form className="note-form" onSubmit={saveNote}>
                <div className="form-heading">
                  <span className="subject-mark blue">NEW</span>
                  <div><h2>记录一条新思考</h2><p>内容只保存在你的当前设备。</p></div>
                </div>
                <label>
                  书名或来源 <em>必填</em>
                  <input value={noteForm.title} onChange={(event) => setNoteForm({ ...noteForm, title: event.target.value })} placeholder="例如：《小岛经济学》" />
                </label>
                <label>
                  原文摘录
                  <textarea value={noteForm.quote} onChange={(event) => setNoteForm({ ...noteForm, quote: event.target.value })} placeholder="哪句话让你停了下来？" rows={3} />
                </label>
                <label>
                  我的理解 <em>必填</em>
                  <textarea value={noteForm.understanding} onChange={(event) => setNoteForm({ ...noteForm, understanding: event.target.value })} placeholder="不用追求正确，先写出自己的理解。" rows={4} />
                </label>
                <label>
                  现实应用 / 待解决的问题
                  <textarea value={noteForm.application} onChange={(event) => setNoteForm({ ...noteForm, application: event.target.value })} placeholder="它能用在生意、投资或生活的哪里？" rows={3} />
                </label>
                <label>
                  标签
                  <input value={noteForm.tags} onChange={(event) => setNoteForm({ ...noteForm, tags: event.target.value })} placeholder="商业, 经济学, 心智模型" />
                </label>
                <button className="primary-action form-submit" type="submit">保存到知识库</button>
              </form>

              <div className="notes-library">
                <div className="library-tools">
                  <label className="search-box">
                    <span>搜索</span>
                    <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索书名、内容或标签" />
                  </label>
                  <button onClick={exportNotes} disabled={notes.length === 0}>导出备份</button>
                </div>

                {filteredNotes.length === 0 ? (
                  <div className="empty-state">
                    <span>READ</span>
                    <h3>{notes.length === 0 ? "你的知识库正等待第一条思考" : "没有找到相关笔记"}</h3>
                    <p>{notes.length === 0 ? "今天读到有启发的内容时，就从左边开始记录。" : "换一个关键词试试。"}</p>
                  </div>
                ) : (
                  <div className="note-list">
                    {filteredNotes.map((note) => (
                      <article className="note-card" key={note.id}>
                        <div className="note-card-head">
                          <div><span>{new Date(note.createdAt).toLocaleDateString("zh-CN")}</span><h3>{note.title}</h3></div>
                          <button onClick={() => deleteNote(note.id)} aria-label={`删除 ${note.title}`}>删除</button>
                        </div>
                        {note.quote && <blockquote>“{note.quote}”</blockquote>}
                        <div className="note-section"><span>我的理解</span><p>{note.understanding}</p></div>
                        {note.application && <div className="note-section"><span>现实应用</span><p>{note.application}</p></div>}
                        {note.tags.length > 0 && <div className="tag-row">{note.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>}
                      </article>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </section>
        )}

        {activeTab === "mentor" && (
          <section className="page mentor-page" aria-labelledby="mentor-title">
            <div className="mentor-hero">
              <div>
                <p className="eyebrow light">AI mentor</p>
                <h1 id="mentor-title">遇到卡点，<br />让 AI 帮你想深一层。</h1>
                <p>选择导师后将打开 ChatGPT，并自动带入适合你的角色与学习方法。</p>
              </div>
              <div className="mentor-orbit" aria-hidden="true"><span>AI</span><i /><i /><i /></div>
            </div>

            <div className="mentor-grid">
              {mentorCards.map((mentor) => {
                const prompt = mentor.id === "english" ? englishPrompt : mentorPrompts[mentor.id];
                return (
                  <article className={`mentor-card ${mentor.accent}`} key={mentor.id}>
                    <span className="mentor-label">{mentor.label}</span>
                    <h2>{mentor.title}</h2>
                    <p>{mentor.description}</p>
                    <div className="mentor-actions">
                      <a href={chatGPTUrl(prompt)} target="_blank" rel="noreferrer">{mentor.action} <span>↗</span></a>
                      <button onClick={() => copyPrompt(prompt)}>复制提示词</button>
                    </div>
                  </article>
                );
              })}
            </div>

            <div className="mentor-note">
              <span>使用建议</span>
              <p>先告诉导师你已经知道什么、卡在哪里。要求它一次只推进一步，并让你先回答，再给结论。</p>
            </div>
          </section>
        )}
      </main>

      <nav className="bottom-nav" aria-label="主要导航">
        {([
          ["home", "TODAY", "今天"],
          ["learn", "PLAN", "学习"],
          ["notes", "BOOK", "知识库"],
          ["mentor", "AI", "导师"],
        ] as const).map(([id, icon, label]) => (
          <button key={id} className={activeTab === id ? "active" : ""} onClick={() => { setActiveTab(id); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
            <span>{icon}</span><small>{label}</small>
          </button>
        ))}
      </nav>

      {installHelpOpen && (
        <div className="modal-backdrop" role="presentation" onClick={() => setInstallHelpOpen(false)}>
          <div className="install-modal" role="dialog" aria-modal="true" aria-labelledby="install-title" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setInstallHelpOpen(false)} aria-label="关闭">×</button>
            <span className="brand-mark large">L</span>
            <h2 id="install-title">把 LifeOS 放到桌面</h2>
            {isIos ? (
              <ol>
                <li>请用 Safari 打开这个网址。</li>
                <li>点击底部的“分享”按钮。</li>
                <li>向下滑动，选择“添加到主屏幕”。</li>
              </ol>
            ) : (
              <ol>
                <li>打开浏览器右上角菜单。</li>
                <li>选择“安装应用”或“添加到主屏幕”。</li>
                <li>确认后即可像 App 一样全屏使用。</li>
              </ol>
            )}
            <button className="primary-action" onClick={() => setInstallHelpOpen(false)}>我知道了</button>
          </div>
        </div>
      )}

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
