export type EnglishDay = {
  day: number;
  theme: string;
  scene: string;
  vocabulary: string[];
  phrases: string[];
  dialogue: [string, string][];
  mission: string;
};

const englishBlueprints: Omit<EnglishDay, "day">[] = [
  {
    theme: "自然地介绍自己",
    scene: "第一次见到新朋友",
    vocabulary: ["introduce", "hometown", "currently", "interested"],
    phrases: ["I’m originally from…", "I currently work in…", "I’m really interested in…"],
    dialogue: [["AI", "Hi, nice to meet you. Tell me a little about yourself."], ["你", "Hi! I’m from China, and I currently work in…"]],
    mission: "录一段 60 秒自我介绍，并让 AI 连续追问 3 个问题。",
  },
  {
    theme: "聊日常作息",
    scene: "和同事谈论一天的安排",
    vocabulary: ["routine", "usually", "schedule", "productive"],
    phrases: ["I usually start my day by…", "My schedule is quite…", "I’m most productive when…"],
    dialogue: [["AI", "What does a typical weekday look like for you?"], ["你", "I usually start my day by checking…"]],
    mission: "用时间顺序描述从起床到睡觉的一天。",
  },
  {
    theme: "兴趣与爱好",
    scene: "周末聚会的轻松聊天",
    vocabulary: ["hobby", "relax", "recently", "passionate"],
    phrases: ["In my free time, I enjoy…", "I’ve recently started…", "What I like most is…"],
    dialogue: [["AI", "What do you like doing when you have some free time?"], ["你", "In my free time, I enjoy reading about…"]],
    mission: "介绍 2 个爱好，并解释为什么喜欢。",
  },
  {
    theme: "家人与朋友",
    scene: "向朋友介绍重要的人",
    vocabulary: ["supportive", "relationship", "close", "personality"],
    phrases: ["I’m very close to…", "We have a lot in common.", "The thing I admire is…"],
    dialogue: [["AI", "Who are you closest to in your family?"], ["你", "I’m very close to… because…"]],
    mission: "描述一个重要的人，包括性格和一件共同经历。",
  },
  {
    theme: "点餐与口味",
    scene: "在餐厅点餐并提出要求",
    vocabulary: ["recommend", "ingredient", "spicy", "allergic"],
    phrases: ["What would you recommend?", "Could I have this without…?", "I’ll go with…"],
    dialogue: [["AI", "Good evening. Are you ready to order?"], ["你", "Almost. What would you recommend for someone who likes…?"]],
    mission: "完成一次从询问推荐到结账的完整点餐对话。",
  },
  {
    theme: "购物与比较",
    scene: "在商店比较两件商品",
    vocabulary: ["quality", "durable", "affordable", "compare"],
    phrases: ["What’s the difference between…?", "Is there a more affordable option?", "I’m looking for something that…"],
    dialogue: [["AI", "Can I help you find something?"], ["你", "Yes, I’m looking for something that is durable and…"]],
    mission: "比较两件商品的价格、质量和适用场景。",
  },
  {
    theme: "问路与导航",
    scene: "在陌生城市寻找目的地",
    vocabulary: ["direction", "intersection", "opposite", "nearby"],
    phrases: ["Could you tell me how to get to…?", "Is it within walking distance?", "Did you say I should turn…?"],
    dialogue: [["AI", "Sure, where are you trying to go?"], ["你", "I’m trying to get to the nearest…"]],
    mission: "听完路线后，用自己的话复述并确认。",
  },
  {
    theme: "天气与计划",
    scene: "根据天气调整周末安排",
    vocabulary: ["forecast", "humid", "cancel", "alternative"],
    phrases: ["The forecast says…", "If it rains, we could…", "How about we… instead?"],
    dialogue: [["AI", "It looks like it might rain this weekend."], ["你", "If it rains, we could change our plan and…"]],
    mission: "针对晴天和雨天各提出一个计划。",
  },
  {
    theme: "旅行与酒店入住",
    scene: "办理酒店入住并确认设施",
    vocabulary: ["reservation", "available", "included", "checkout"],
    phrases: ["I have a reservation under…", "Is breakfast included?", "Could I request a room with…?"],
    dialogue: [["AI", "Welcome. May I have your name, please?"], ["你", "I have a reservation under the name…"]],
    mission: "完成入住、询问早餐、Wi-Fi 和退房时间。",
  },
  {
    theme: "机场与航班",
    scene: "值机并处理座位问题",
    vocabulary: ["boarding", "luggage", "aisle", "delayed"],
    phrases: ["Where can I check in?", "Could I have an aisle seat?", "Has the boarding time changed?"],
    dialogue: [["AI", "May I see your passport and booking confirmation?"], ["你", "Of course. Could I also ask for an aisle seat?"]],
    mission: "模拟值机、托运行李和确认登机口。",
  },
  {
    theme: "身体不适与看医生",
    scene: "向医生清楚描述症状",
    vocabulary: ["symptom", "painful", "medicine", "appointment"],
    phrases: ["I’ve been feeling… for…", "It hurts when I…", "Should I avoid…?"],
    dialogue: [["AI", "What seems to be the problem today?"], ["你", "I’ve been feeling unwell for two days. I have…"]],
    mission: "描述症状、持续时间和严重程度，并问 2 个问题。",
  },
  {
    theme: "电话预约",
    scene: "打电话预约并更改时间",
    vocabulary: ["appointment", "available", "reschedule", "confirm"],
    phrases: ["I’d like to make an appointment.", "Would any time after… work?", "Could we reschedule it to…?"],
    dialogue: [["AI", "Good morning. How may I help you?"], ["你", "I’d like to make an appointment for…"]],
    mission: "预约一个时间，再提出一次改期请求。",
  },
  {
    theme: "表达观点",
    scene: "讨论一个熟悉的话题",
    vocabulary: ["opinion", "benefit", "drawback", "perspective"],
    phrases: ["From my perspective…", "The main benefit is…", "I see your point, but…"],
    dialogue: [["AI", "Do you think working from home is better?"], ["你", "From my perspective, the main benefit is…"]],
    mission: "对一个话题表达立场、两个理由和一个保留意见。",
  },
  {
    theme: "礼貌地同意与反对",
    scene: "小组讨论中回应他人",
    vocabulary: ["agree", "concern", "reasonable", "alternative"],
    phrases: ["I completely agree that…", "I’m not sure I see it that way.", "Could we consider…?"],
    dialogue: [["AI", "I think price should be our only consideration."], ["你", "I see your point, but I’m concerned about…"]],
    mission: "分别练习完全同意、部分同意和礼貌反对。",
  },
  {
    theme: "讲述过去经历",
    scene: "分享一次难忘的经历",
    vocabulary: ["experience", "unexpected", "realized", "memorable"],
    phrases: ["A few years ago…", "What happened next was…", "That experience taught me…"],
    dialogue: [["AI", "Tell me about an experience you’ll never forget."], ["你", "A few years ago, I had an unexpected experience when…"]],
    mission: "用开始—转折—结果讲一个 2 分钟故事。",
  },
  {
    theme: "未来计划与目标",
    scene: "谈论未来一年的成长计划",
    vocabulary: ["goal", "improve", "achieve", "challenge"],
    phrases: ["My main goal is to…", "I’m planning to…", "The biggest challenge will be…"],
    dialogue: [["AI", "What would you like to achieve this year?"], ["你", "My main goal is to improve… by…"]],
    mission: "说出一个目标、三个行动和一个衡量方法。",
  },
  {
    theme: "工作职责",
    scene: "向新客户介绍自己的工作",
    vocabulary: ["responsible", "manage", "client", "process"],
    phrases: ["I’m responsible for…", "A typical project involves…", "I mainly work with…"],
    dialogue: [["AI", "What exactly do you do in your role?"], ["你", "I’m responsible for managing…"]],
    mission: "用非专业人士也能听懂的方式介绍自己的工作。",
  },
  {
    theme: "介绍产品与服务",
    scene: "向潜在客户做一分钟介绍",
    vocabulary: ["solution", "customer", "reliable", "value"],
    phrases: ["We help customers…", "What makes us different is…", "The key value is…"],
    dialogue: [["AI", "So, what does your business offer?"], ["你", "We help customers solve… by providing…"]],
    mission: "用问题—方案—价值结构介绍一项业务。",
  },
  {
    theme: "商务寒暄",
    scene: "会议开始前建立联系",
    vocabulary: ["industry", "conference", "opportunity", "connection"],
    phrases: ["How did you get into…?", "What brings you here today?", "It would be great to stay in touch."],
    dialogue: [["AI", "Hi, I don’t think we’ve met. I’m Alex."], ["你", "Nice to meet you, Alex. What brings you here today?"]],
    mission: "完成开场、两个追问和自然结束对话。",
  },
  {
    theme: "主持简短会议",
    scene: "开启并推进一次工作会议",
    vocabulary: ["agenda", "priority", "update", "decision"],
    phrases: ["Let’s get started.", "The main goal today is…", "Before we move on…"],
    dialogue: [["AI", "Everyone is here and ready."], ["你", "Great, let’s get started. The main goal today is…"]],
    mission: "主持 5 分钟模拟会议：目标、议题、决定、下一步。",
  },
  {
    theme: "汇报进展",
    scene: "向主管做项目更新",
    vocabulary: ["progress", "milestone", "issue", "deadline"],
    phrases: ["So far, we’ve completed…", "We’re currently working on…", "The main issue is…"],
    dialogue: [["AI", "Can you give me a quick update?"], ["你", "So far, we’ve completed… and we’re on track to…"]],
    mission: "用完成、进行中、风险、下一步四部分汇报。",
  },
  {
    theme: "提出建议",
    scene: "为团队问题提供方案",
    vocabulary: ["suggest", "option", "efficient", "implement"],
    phrases: ["I’d suggest that we…", "One option would be…", "This could help us…"],
    dialogue: [["AI", "Sales have been slower this month. Any ideas?"], ["你", "One option would be to… This could help us…"]],
    mission: "提出两个方案，比较利弊并推荐一个。",
  },
  {
    theme: "谈判价格",
    scene: "与供应商讨论报价",
    vocabulary: ["quotation", "discount", "quantity", "terms"],
    phrases: ["Is there any flexibility on the price?", "If we increase the quantity…", "Could you meet us halfway?"],
    dialogue: [["AI", "Our quoted price is $20 per unit."], ["你", "Is there any flexibility if we increase the quantity to…?"]],
    mission: "争取折扣、确认数量和付款条件。",
  },
  {
    theme: "客户需求访谈",
    scene: "通过提问理解客户问题",
    vocabulary: ["requirement", "priority", "challenge", "expectation"],
    phrases: ["What is your biggest challenge?", "What would an ideal solution look like?", "Which factor matters most?"],
    dialogue: [["AI", "We’re looking for a more reliable supplier."], ["你", "I understand. What reliability issues have you experienced?"]],
    mission: "只用提问完成一次 5 问需求访谈，再总结需求。",
  },
  {
    theme: "处理投诉",
    scene: "回应不满意的客户",
    vocabulary: ["apologize", "resolve", "inconvenience", "replacement"],
    phrases: ["I’m sorry to hear that.", "Let me make sure I understand…", "Here’s what we can do…"],
    dialogue: [["AI", "My order arrived late and one item is damaged."], ["你", "I’m sorry about the inconvenience. Let me make sure I understand…"]],
    mission: "完成倾听、复述、道歉、解决方案和跟进。",
  },
  {
    theme: "解释数据变化",
    scene: "说明销售或利润图表",
    vocabulary: ["increase", "decline", "stable", "factor"],
    phrases: ["The figure increased by…", "The main reason was…", "Compared with last year…"],
    dialogue: [["AI", "Why did profit grow more slowly than revenue?"], ["你", "The main reason was that costs increased by…"]],
    mission: "选一个真实数据，用趋势—原因—影响解释。",
  },
  {
    theme: "澄清与确认",
    scene: "没听懂时保持对话流畅",
    vocabulary: ["clarify", "specifically", "confirm", "understand"],
    phrases: ["Could you say that again?", "What do you mean by…?", "So, if I understand correctly…"],
    dialogue: [["AI", "We need to optimize the downstream conversion funnel."], ["你", "Could you clarify what you mean by downstream conversion?"]],
    mission: "在对话中主动使用 3 种澄清方式。",
  },
  {
    theme: "即兴回答",
    scene: "面对没有准备的问题",
    vocabulary: ["consider", "example", "reason", "overall"],
    phrases: ["That’s an interesting question.", "Let me think for a moment.", "A good example would be…"],
    dialogue: [["AI", "What is one belief you have changed recently?"], ["你", "That’s an interesting question. Let me think for a moment…"]],
    mission: "随机回答 5 个问题，每题连续说 45 秒。",
  },
  {
    theme: "总结复杂内容",
    scene: "把一段长信息说清楚",
    vocabulary: ["summary", "essential", "point", "conclusion"],
    phrases: ["The main point is…", "There are three things to remember.", "In short…"],
    dialogue: [["AI", "Can you summarize what we’ve discussed?"], ["你", "Sure. There are three things to remember. First…"]],
    mission: "听一段 2 分钟内容，压缩成 30 秒总结。",
  },
  {
    theme: "说服与论证",
    scene: "说服对方接受一个方案",
    vocabulary: ["evidence", "impact", "convince", "practical"],
    phrases: ["The strongest reason is…", "The evidence suggests…", "This is practical because…"],
    dialogue: [["AI", "Why should we choose your proposal?"], ["你", "The strongest reason is the long-term impact on…"]],
    mission: "用主张—证据—例子—结论完成 2 分钟论证。",
  },
  {
    theme: "模拟面试",
    scene: "回答能力与经历问题",
    vocabulary: ["strength", "achievement", "challenge", "contribute"],
    phrases: ["One of my strengths is…", "A good example is…", "I learned that…"],
    dialogue: [["AI", "Tell me about a challenge you overcame."], ["你", "One challenge I faced was… The action I took was…"]],
    mission: "用 STAR 结构回答 3 个面试问题。",
  },
  {
    theme: "自由主题长对话",
    scene: "围绕一个喜欢的话题深入交流",
    vocabulary: ["insight", "curious", "assumption", "connect"],
    phrases: ["What makes this interesting is…", "That reminds me of…", "I’m curious about…"],
    dialogue: [["AI", "Choose any topic you care about. Why does it matter to you?"], ["你", "I’d like to talk about… What makes it interesting is…"]],
    mission: "不看稿与 AI 连续对话 10 分钟，每次回答后主动反问。",
  },
  {
    theme: "33 天成果展示",
    scene: "完成一次综合英语表达",
    vocabulary: ["progress", "confidence", "reflection", "continue"],
    phrases: ["Over the past 33 days…", "I’m now more confident in…", "My next step is…"],
    dialogue: [["AI", "How has your English changed over these 33 days?"], ["你", "Over the past 33 days, I’ve become more confident in…"]],
    mission: "完成 5 分钟英文总结，并让 AI 给出流利度、语法、词汇和下一步评分。",
  },
];

export const englishCurriculum: EnglishDay[] = englishBlueprints.map((item, index) => ({
  day: index + 1,
  ...item,
}));

type InvestingPhase = {
  name: string;
  description: string;
  topics: string[];
};

const investingPhases: InvestingPhase[] = [
  {
    name: "企业语言",
    description: "先学会用经营者视角理解一家公司。",
    topics: ["企业如何创造价值", "收入、成本与利润", "毛利与毛利率", "费用与经营杠杆", "现金流为什么重要", "资产、负债与所有者权益", "商业周期与企业阶段", "好生意的三个特征", "建立你的分析词典"],
  },
  {
    name: "三张财务报表",
    description: "建立利润表、资产负债表与现金流量表的连接。",
    topics: ["读懂利润表", "收入确认与增长质量", "营业利润与净利润", "读懂资产负债表", "应收账款与存货", "有息负债与偿债能力", "读懂现金流量表", "三张表如何互相验证", "识别利润与现金的背离"],
  },
  {
    name: "盈利质量",
    description: "判断利润是否真实、稳定、可持续。",
    topics: ["ROE 的分解", "ROIC 与资本效率", "自由现金流", "净利率与竞争结构", "周转率与运营效率", "资本开支的两种类型", "一次性损益", "会计估计与利润调节", "制作盈利质量检查表"],
  },
  {
    name: "商业模式",
    description: "看清客户、价值、成本和赚钱机制。",
    topics: ["客户是谁", "客户为什么付钱", "收入模式", "成本结构", "供应链位置", "规模经济", "网络效应", "转换成本", "用一页纸画商业模式"],
  },
  {
    name: "护城河",
    description: "区分真正的长期优势和短期好运。",
    topics: ["品牌与定价权", "成本优势", "网络效应的强弱", "转换成本的证据", "专利、牌照与稀缺资源", "渠道与心智占领", "管理能力是否是护城河", "护城河被侵蚀的信号", "给企业的护城河打分"],
  },
  {
    name: "行业与竞争",
    description: "把公司放回行业里判断位置。",
    topics: ["行业价值链", "市场空间与渗透率", "竞争格局", "波特五力", "周期性与防御性", "上游议价能力", "下游客户集中度", "替代品风险", "制作行业地图"],
  },
  {
    name: "管理层与治理",
    description: "判断资本配置者是否值得托付。",
    topics: ["管理层诚信", "激励机制", "资本配置框架", "分红与回购", "并购的价值与陷阱", "关联交易", "大股东与小股东利益", "管理层言行一致性", "写一份治理评估"],
  },
  {
    name: "估值基础",
    description: "用多种方法建立价格与价值的边界。",
    topics: ["价格与价值", "市盈率的正确用法", "市净率适用场景", "EV/EBITDA", "自由现金流收益率", "DCF 的核心逻辑", "折现率与永续增长", "相对估值", "建立估值区间"],
  },
  {
    name: "风险与决策",
    description: "在不确定性中保护本金、提高胜率。",
    topics: ["安全边际", "能力圈", "永久性亏损风险", "资产负债表风险", "单一客户与供应商风险", "政策与技术风险", "情景分析", "仓位与组合思维", "写下反方观点"],
  },
  {
    name: "完整企业研究",
    description: "把前 81 天的方法用于一家真实公司。",
    topics: ["选择并定义研究对象", "收集十年核心数据", "还原商业模式", "分析行业与竞争者", "验证护城河", "评价管理层", "建立三种估值情景", "撰写投资备忘录", "复盘并形成自己的框架"],
  },
];

const taskPatterns = [
  "用自己的话写出 3 条定义，并举一个生活中的例子。",
  "找一家熟悉公司的数据，完成一张对比小表。",
  "用“现象—原因—影响”写 150 字分析。",
  "向 AI 提 3 个追问，直到你能不看资料复述。",
  "找出一个正面证据和一个反面证据。",
  "用加油站、CNC 或 Ozon 业务做类比。",
  "阅读一份真实年报中的相关章节，摘录关键数字。",
  "列出最容易误判的 3 个地方。",
  "把本阶段内容压缩为一页分析清单。",
];

export type InvestingDay = {
  day: number;
  phase: string;
  phaseDescription: string;
  concept: string;
  task: string;
  output: string;
};

export const investingCurriculum: InvestingDay[] = investingPhases.flatMap((phase, phaseIndex) =>
  phase.topics.map((concept, topicIndex) => ({
    day: phaseIndex * 9 + topicIndex + 1,
    phase: phase.name,
    phaseDescription: phase.description,
    concept,
    task: taskPatterns[topicIndex],
    output: topicIndex === 8 ? `完成《${phase.name}》阶段总结` : `一张“${concept}”学习卡片`,
  })),
);
