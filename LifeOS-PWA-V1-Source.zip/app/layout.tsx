import type { Metadata, Viewport } from "next";
import "./globals.css";

const githubRepository = process.env.GITHUB_REPOSITORY?.split("/")[1];
const githubOwner = process.env.GITHUB_REPOSITORY_OWNER;
const vercelHost = process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL;
const publicSiteUrl = process.env.NEXT_PUBLIC_SITE_URL
  || (vercelHost ? `https://${vercelHost}` : undefined)
  || (process.env.GITHUB_ACTIONS === "true" && githubOwner && githubRepository
    ? `https://${githubOwner}.github.io/${githubRepository}`
    : undefined);

export const metadata: Metadata = {
  metadataBase: publicSiteUrl ? new URL(publicSiteUrl) : undefined,
  title: "LifeOS · 学习成长工作台",
  description: "英语、投资与阅读的每日学习系统。记录进度，完成课程，把知识变成长期能力。",
  applicationName: "LifeOS",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "LifeOS",
  },
  formatDetection: {
    telephone: false,
  },
  icons: {
    icon: [
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    type: "website",
    locale: "zh_CN",
    title: "LifeOS · 今天，也向前一点",
    description: "英语、投资与阅读的每日学习系统。",
    images: publicSiteUrl
      ? [{ url: "/og.png", width: 1200, height: 630, alt: "LifeOS 学习成长工作台" }]
      : undefined,
  },
  twitter: {
    card: "summary_large_image",
    title: "LifeOS · 今天，也向前一点",
    description: "英语、投资与阅读的每日学习系统。",
    images: publicSiteUrl ? ["/og.png"] : undefined,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#174f42",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
